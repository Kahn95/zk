---
tags:
title: insert-title-here
#date: 2020-11-05 20:45:59
published: false
#sidebar:
#    nav: cryptomat
---

{: .info}
**tl;dr:** Write an intro paragraph here.

<!--more-->

<p hidden>$$
\def\Adv{\mathcal{A}}
\def\Badv{\mathcal{B}}
\def\vect#1{\mathbf{#1}}
$$</p>

---

{% include refs.md %}
