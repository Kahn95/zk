Finish:

 - AAD from CF VCs
 - A step closer to scalable VSS and DKG
 - Zero knowledge simulation
 - The courage to be disliked
 - C++ guidelines

Polish:

 - Crypto assumptions in hidden order groups
    + Add examples of cryptosystems based on the assumption and give reduction
 - RSA accumulators
    - Add non-membership proof

Future:

 - Edrax VC
 - GIPA and inner products, including KZG trick
