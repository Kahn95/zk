#!/bin/bash

scriptdir=$(cd $(dirname $(readlink -f $0)); pwd -P)

$scriptdir/open-post.sh l
