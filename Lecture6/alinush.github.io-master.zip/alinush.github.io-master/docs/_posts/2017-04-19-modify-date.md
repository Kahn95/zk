---
title: TeXt - Modify Date
key: 20170419
tags: TeXt
modify_date: 2017-09-09
---

Article with modify date.

<!--more-->

**front matter:**

    ---
    ...
    modify_date: 2017-09-09
    ---
