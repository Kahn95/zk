extern crate num_bigint_dig as num_bigint;
extern crate num_traits;

mod analyzers;
pub mod check_types;
mod decorators;
