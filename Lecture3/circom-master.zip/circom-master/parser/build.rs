extern crate lalrpop;

fn main() {
    lalrpop::process_root().unwrap();
}
