---
description: >-
  This tutorial will guide you through the process of writing your first program
  using the main features of circom: signals, variables, templates, components,
  and arrays.
---

# Testing circuits 

## Writing a test

## Run our tests
