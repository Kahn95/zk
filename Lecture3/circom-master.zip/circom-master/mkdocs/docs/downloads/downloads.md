---
description: >-
  A page with compiled circom, to download and use.
---

[**circom Linux binary**](https://github.com/iden3/circom/releases/latest/download/circom-linux-amd64)

[**circom macOS binary**](https://github.com/iden3/circom/releases/latest/download/circom-macos-amd64)

[**circom Windows binary**](https://github.com/iden3/circom/releases/latest/download/circom-windows-amd64.exe)