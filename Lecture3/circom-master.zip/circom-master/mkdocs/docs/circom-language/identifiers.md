# Identifiers

Any non-reserved keyword that starts with any number of “\__” followed by an ASCII alphabetic character and followed by any number of alphabetic or numeric chars, “\_”_ or “$” can be used as identifier. Examples of identifiers are the following:

```text
signal input _in; 
var o_u_t;
var o$o;
 
```



