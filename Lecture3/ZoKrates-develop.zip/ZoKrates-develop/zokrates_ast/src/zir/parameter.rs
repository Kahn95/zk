use super::Variable;

pub type Parameter<'ast> = crate::common::Parameter<Variable<'ast>>;
