pub trait Value {
    type Value: Clone;
}
