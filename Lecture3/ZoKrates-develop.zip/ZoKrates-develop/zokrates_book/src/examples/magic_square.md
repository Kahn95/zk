# A ZK Magic Square in the browser

<iframe
    src="https://zokrates.github.io/zokrates-nextjs-demo/"
    style="width:100%;min-height:100vh;border:none"
    title="A ZK Magic Square">
</iframe>