# ZoKrates Examples

This section covers examples of using the ZoKrates programming language.

- [A SNARK Powered RNG](./rng_tutorial.md)
- [Proving knowledge of a hash preimage](./sha256example.md)