#!/bin/bash
set -e

docker build -t zokrates_js -f zokrates_js/Dockerfile .