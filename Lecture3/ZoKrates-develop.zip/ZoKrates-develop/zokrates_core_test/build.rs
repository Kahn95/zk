use zokrates_test_derive::write_tests;

fn main() {
    // generate tests
    write_tests("./tests/tests/");
}
